# VIPN

Menu bar приложение для подключения к корпоративному Cisco VPN.

## Как работает VPN-часть

VIPN не реализует собственный VPN-протокол. Он управляет установленным Cisco Secure Client / AnyConnect через CLI.

Обычный сценарий:

1. В настройках указывается адрес VPN-сервера.
2. Указываются логин, пароль и TOTP secret.
3. VIPN генерирует одноразовый код.
4. VIPN вызывает Cisco CLI:

```text
vpn -s connect <server>
```

5. В stdin передаются логин, пароль и OTP.
6. Статус подключения проверяется через Cisco CLI state.
7. При отключении VIPN вызывает:

```text
vpn disconnect
```

Приложение отображается в строке меню macOS, показывает статус подключения и оставшееся время сессии.

## Управление из терминала

После стандартной установки перетаскиванием `VIPN.app` в `/Applications`
доступны три команды:

```bash
/Applications/VIPN.app/Contents/MacOS/VIPN connect
/Applications/VIPN.app/Contents/MacOS/VIPN disconnect
/Applications/VIPN.app/Contents/MacOS/VIPN status
```

Команды `connect` и `disconnect` идут по тому же пути `VPNManager`, что и пункты
меню: приложение использует сохранённые данные из Keychain, TOTP, Cisco CLI,
состояние сессии и включённую DNS-схему. `status` выполняет свежую проверку
состояния через Cisco CLI. Если приложение в строке меню не запущено, команда
запускает его в фоне и ждёт управляющий endpoint.

Для терминального управления Cisco Secure Client / AnyConnect и его VPN service
должны быть установлены и работоспособны. Успешный результат выводится в stdout
одной строкой:

```text
connected
disconnected
```

Коды завершения:

- `0` — запрошенное состояние достигнуто или `status` получил известное
  состояние;
- `1` — ошибка учётных данных, TOTP, Cisco, VPN-операции или управляющего
  запроса;
- `2` — состояние неизвестно, приложение/Cisco service недоступны или истёк
  тайм-аут;
- `64` — неверное использование командной строки.

В разделе терминальных инструментов настроек можно необязательно нажать
**Установить команду vipnctl…**. После авторизации администратора появится
короткая команда `vipnctl`, указывающая на исполняемый файл внутри установленного
приложения. Полные команды выше работают и без неё. Чтобы удалить короткую
команду вручную:

```bash
sudo rm /usr/local/bin/vipnctl
```

## Настройки

Основные настройки:

- адрес VPN-сервера;
- путь к Cisco CLI, если автоопределение не сработало;
- логин;
- пароль;
- TOTP secret;
- запуск VIPN при входе в macOS;
- DNS при подключении к VPN;
- IP роутера для DNS, если автоопределение шлюза не подходит.

Логин, пароль и TOTP secret хранятся в Keychain.

## DNS при подключении к VPN

По умолчанию DNS-интеграция выключена.

Настройка:

```text
Включать dnsmasq при подключении к VPN
```

Если галка выключена:

- при подключении к Cisco VIPN никак не трогает dnsmasq;
- DNS работает так, как настроит Cisco/macOS;
- это дефолтное поведение.

Если галка включена:

- при подключении к Cisco VIPN включает локальную dnsmasq-схему;
- при отключении Cisco VIPN выключает dnsmasq-схему;
- без активного Cisco VPN dnsmasq не должен использоваться.

## Как работает dnsmasq-схема

Цель схемы: совместить Cisco VPN и OpenWrt/podkop на роутере.

Итоговый поток DNS:

```text
Mac -> /etc/resolver/root -> 127.0.0.1 -> dnsmasq
  выбранные доменные списки -> IP физического шлюза -> OpenWrt/podkop
  остальные домены -> Cisco DNS
```

Что делает VIPN при подключении VPN, если DNS-галка включена:

1. Определяет Homebrew и при необходимости устанавливает `dnsmasq`.
2. Использует указанный IP роутера или автоматически определяет физический шлюз, игнорируя VPN-интерфейсы `utun`.
3. Скачивает выбранные доменные списки из `itdoginfo/allow-domains`.
4. Генерирует:

```text
<homebrew-prefix>/etc/dnsmasq.d/vipn-domains.conf
```

5. Записывает основной конфиг:

```text
<homebrew-prefix>/etc/dnsmasq.conf
```

6. В `dnsmasq.conf` прописывает Cisco DNS из настроек:

```text
server=192.0.2.53
server=198.51.100.53
```

7. Для выбранных списков прописывает forwarding на роутер:

```text
server=/domain.example/<router-ip>
```

8. Запускает dnsmasq через отдельный LaunchDaemon VIPN:

```text
/Library/LaunchDaemons/com.vipn.dnsmasq.plist
```

9. Создаёт root resolver:

```text
/etc/resolver/root
```

с содержимым:

```text
domain .
nameserver 127.0.0.1
search_order 0
```

10. Очищает DNS-кэш macOS.

Что делает VIPN при отключении VPN:

1. Удаляет:

```text
/etc/resolver/root
```

2. Останавливает dnsmasq.
3. Очищает DNS-кэш macOS.

После этого macOS снова работает с DNS так же, как без VIPN/dnsmasq.

## Выбор списков

В настройках DNS можно выбрать несколько доменных списков из:

```text
https://github.com/itdoginfo/allow-domains
```

По умолчанию выбран:

```text
Russia inside
```

Подключены только доменные списки. IP/subnet-списки не используются, потому что dnsmasq управляет DNS-запросами, а не IP-маршрутами.

Под списками показывается дата и время их последней успешной загрузки. Если хотя бы один выбранный список скачать не удалось, сохранённая дата не меняется.

## Пользовательские домены

Кнопка `Добавить свои домены…` открывает отдельное окно со списком дополнительных доменов. Каждый домен указывается с новой строки в формате:

```text
example.com
sub.example.com
```

Полные URL, пути, порты, пробелы и домены на кириллице не принимаются. Если в поле есть ошибка, список не сохраняется, а приложение показывает номера некорректных строк.

Пользовательские домены сохраняются сразу из модального окна и восстанавливаются при следующем открытии. Они объединяются с выбранными внешними списками и направляются на настроенный или автоматически определённый DNS роутера.

Если Cisco VPN уже подключён и DNS-функция включена, VIPN пересобирает конфиг и отправляет helper команду `restart`, не отключая VPN. Если применить изменения сразу не удалось, приложение сообщает, что домены заработают после следующего переподключения VPN.

## Требования для DNS-функции

VIPN автоматически выполняет:

```bash
brew install dnsmasq
```

Если Homebrew отсутствует, приложение откроет Terminal с официальным установщиком Homebrew и последующей установкой `dnsmasq`. Поддерживаются стандартные пути Apple Silicon (`/opt/homebrew`) и Intel (`/usr/local`).

Так как dnsmasq и `/etc/resolver/root` требуют повышенных прав, VIPN использует отдельный root helper.

При первом включении DNS-схемы macOS попросит пароль администратора один раз, чтобы установить:

```text
/Library/Application Support/VIPN/vipn-dns-helper.sh
/Library/LaunchDaemons/com.vipn.dnshelper.plist
```

После этого при обычном включении и выключении VPN пароль вводить не нужно.

Helper работает как LaunchDaemon от root, но не выполняет произвольные команды из приложения. VIPN может записать только короткую команду в:

```text
/var/tmp/vipn-dns-helper/command
```

Разрешённые команды:

```text
enable
disable
restart
```

Перед выполнением helper проверяет:

- файл команды принадлежит текущему пользователю;
- права файла команды `600` или `400`;
- команда входит в разрешённый список.

Это сделано, чтобы не держать в приложении постоянный sudo-доступ и не давать возможность выполнить произвольный shell-код через файл команды.

Если dnsmasq был запущен вручную как пользовательская служба и падает с ошибкой, остановить её:

```bash
brew services stop dnsmasq
```

VIPN запускает и останавливает dnsmasq через установленный root helper. Helper не вызывает `brew services`, потому что Homebrew не должен запускаться от root в таком сценарии. Вместо этого helper напрямую запускает:

```text
<homebrew-prefix>/opt/dnsmasq/sbin/dnsmasq
```

с конфигом:

```text
<homebrew-prefix>/etc/dnsmasq.conf
```

Логи helper:

```text
/var/log/vipn-dns-helper.log
/var/log/vipn-dns-helper.stdout.log
/var/log/vipn-dns-helper.stderr.log
```

Логи dnsmasq, запущенного VIPN:

```text
/var/log/vipn-dnsmasq.stdout.log
/var/log/vipn-dnsmasq.stderr.log
```

## Проверка DNS

Проверить, что macOS использует root resolver:

```bash
scutil --dns
```

Должен быть блок:

```text
domain   : .
nameserver[0] : 127.0.0.1
```

Проверить dnsmasq:

```bash
dig @127.0.0.1 youtube.com
```

Проверить, что выбранные домены идут на роутер:

```bash
sudo tcpdump -ni en0 host <router-ip> and port 53
```

## Быстрый откат DNS

Если что-то пошло не так:

```bash
sudo rm -f /etc/resolver/root
sudo brew services stop dnsmasq
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

После этого DNS-схема VIPN отключена.

## Полный откат DNS-файлов

```bash
sudo launchctl bootout system /Library/LaunchDaemons/com.vipn.dnshelper.plist 2>/dev/null || true
sudo launchctl bootout system /Library/LaunchDaemons/com.vipn.dnsmasq.plist 2>/dev/null || true
sudo rm -f /Library/LaunchDaemons/com.vipn.dnshelper.plist
sudo rm -f /Library/LaunchDaemons/com.vipn.dnsmasq.plist
sudo rm -f "/Library/Application Support/VIPN/vipn-dns-helper.sh"
sudo rm -f /etc/resolver/root
sudo brew services stop dnsmasq
rm -f <homebrew-prefix>/etc/dnsmasq.d/vipn-domains.conf
rm -rf /var/tmp/vipn-dns-helper
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

Если dnsmasq больше не нужен:

```bash
brew uninstall dnsmasq
```

## Dock-иконка

Важно: чтобы приложение показывало иконку в Dock при открытых окнах, в target Info.plist не должно быть ключа:

```text
Application is agent (UIElement)
LSUIElement
```

Если этот ключ включён в Xcode target, Dock-иконка не появится.
